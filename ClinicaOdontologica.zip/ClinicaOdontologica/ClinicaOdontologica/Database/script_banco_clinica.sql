﻿/* =====================================================================
   SISTEMA DE GESTÃO DE CLÍNICA ODONTOLÓGICA  -  SQL Server
   Script de criação e população do banco de dados (ENTREGA 03)

   Como executar: abra no SSMS / Azure Data Studio e execute o script inteiro (F5).
   O script é re-executável: recria as tabelas e os registros do zero.

   OBSERVAÇÕES (LGPD / segurança)
   - paciente.cpf  : gravado CRIPTOGRAFADO (AES-256, Base64). A aplicação criptografa
                     e descriptografa automaticamente; por isso a coluna é VARCHAR(100).
                     Os valores abaixo foram gerados com a chave de desenvolvimento
                     'Seguranca:ChaveProtecao' do appsettings.json.
   - usuario.senha : gravada como HASH PBKDF2-SHA256 com salt (nunca texto puro).

   USUÁRIOS PARA TESTE DO LOGIN
       login: admin      senha: Admin@123
       login: recepcao   senha: Recep@123
       login: dentista   senha: Dente@123
   ===================================================================== */

IF DB_ID('dbClinicaOdontologica') IS NULL
    CREATE DATABASE dbClinicaOdontologica;
GO

USE dbClinicaOdontologica;
GO

/* ---------- Remoção das tabelas (ordem inversa das dependências) ---------- */
IF OBJECT_ID('dbo.agendamento',   'U') IS NOT NULL DROP TABLE dbo.agendamento;
IF OBJECT_ID('dbo.procedimento',  'U') IS NOT NULL DROP TABLE dbo.procedimento;
IF OBJECT_ID('dbo.paciente',      'U') IS NOT NULL DROP TABLE dbo.paciente;
IF OBJECT_ID('dbo.usuario',       'U') IS NOT NULL DROP TABLE dbo.usuario;
GO

/* ---------- Criação das tabelas ---------- */
CREATE TABLE dbo.usuario (
    id_usuario  INT IDENTITY(1,1) NOT NULL,
    nome        VARCHAR(100)      NOT NULL,
    login       VARCHAR(50)       NOT NULL,
    senha       VARCHAR(255)      NOT NULL,   -- hash PBKDF2
    CONSTRAINT pk_usuario       PRIMARY KEY (id_usuario),
    CONSTRAINT uq_usuario_login UNIQUE (login)
);

CREATE TABLE dbo.paciente (
    id_paciente INT IDENTITY(1,1) NOT NULL,
    nome        VARCHAR(100)      NOT NULL,
    cpf         VARCHAR(100)      NOT NULL,   -- CPF criptografado (AES-256)
    telefone    VARCHAR(20)       NOT NULL,
    CONSTRAINT pk_paciente     PRIMARY KEY (id_paciente),
    CONSTRAINT uq_paciente_cpf UNIQUE (cpf)
);

CREATE TABLE dbo.procedimento (
    id_procedimento INT IDENTITY(1,1) NOT NULL,
    nome            VARCHAR(100)      NOT NULL,
    valor           DECIMAL(10,2)     NOT NULL,
    id_paciente     INT               NOT NULL,   -- todo procedimento pertence a um paciente
    CONSTRAINT pk_procedimento          PRIMARY KEY (id_procedimento),
    CONSTRAINT ck_procedimento_valor    CHECK (valor > 0),
    CONSTRAINT fk_procedimento_paciente FOREIGN KEY (id_paciente) REFERENCES dbo.paciente (id_paciente)
);

CREATE TABLE dbo.agendamento (
    id_agendamento  INT IDENTITY(1,1) NOT NULL,
    data_consulta   DATETIME          NOT NULL,
    observacoes     VARCHAR(255)      NULL,
    id_paciente     INT               NOT NULL,
    id_procedimento INT               NOT NULL,
    id_usuario      INT               NOT NULL,   -- usuário que realizou o agendamento
    CONSTRAINT pk_agendamento             PRIMARY KEY (id_agendamento),
    CONSTRAINT fk_agendamento_paciente      FOREIGN KEY (id_paciente)     REFERENCES dbo.paciente (id_paciente),
    CONSTRAINT fk_agendamento_procedimento  FOREIGN KEY (id_procedimento) REFERENCES dbo.procedimento (id_procedimento),
    CONSTRAINT fk_agendamento_usuario       FOREIGN KEY (id_usuario)      REFERENCES dbo.usuario (id_usuario)
);
GO

CREATE INDEX ix_agendamento_data_consulta ON dbo.agendamento (data_consulta);
GO

/* ---------- População (mínimo de 3 registros por tabela) ---------- */

INSERT INTO dbo.usuario (nome, login, senha) VALUES
    (N'Administrador da Clínica', 'admin', 'PBKDF2$100000$UThwxgYLE+16J6tbmeWnVw==$1Y4StbsWexc11fLc/rhTAEAJy3dOYY+jlkyYYYZPYSM='),
    (N'Maria Recepcionista', 'recepcao', 'PBKDF2$100000$27f0uIBz2OpGFZlHqIEi2g==$Poyactq004jZNr362cnMvrn4a1H1dCVj3CzlezokNgY='),
    (N'Dr. Carlos Dentista', 'dentista', 'PBKDF2$100000$86DtqmX+RfHjtVHK9+dTxA==$mo5QyT/or+nwwxucLz04/bzDhGfsDA+PmfLAOT03/fI=');
GO

INSERT INTO dbo.paciente (nome, cpf, telefone) VALUES
    (N'Ana Beatriz Santos', 'B5XLnXxlMXOgiU98KdKav1oUos0rThEyIB28DTy786s=', '(79) 99811-2233'),
    (N'João Pedro Oliveira', 'YstkLvwVvxXk7rnoxi6EtydvWiN1HXp/Wqvj9uKJQKY=', '(79) 99922-3344'),
    (N'Mariana Costa Lima', 'DYcu3miWFWNYZxf05GZLjtUpxfC0RWc87CdlhCeRZvw=', '(79) 99733-4455'),
    (N'Carlos Eduardo Ramos', 'TDlxz6i52xkWrLvNd6tnPLFgxZljjoPLXWgCwNbuDa0=', '(79) 99644-5566'),
    (N'Fernanda Souza Alves', 'VQBaXG/ot82pQaqFciKR5+AJMmtVaEPDVvgrGcysTgY=', '(79) 99555-6677');
GO

INSERT INTO dbo.procedimento (nome, valor, id_paciente) VALUES
    (N'Limpeza e profilaxia', 150.00, 1),
    (N'Restauração em resina', 220.00, 2),
    (N'Tratamento de canal', 650.00, 3),
    (N'Clareamento dental', 800.00, 4),
    (N'Extração de siso', 350.00, 5),
    (N'Avaliação ortodôntica', 120.00, 1);
GO

INSERT INTO dbo.agendamento (data_consulta, observacoes, id_paciente, id_procedimento, id_usuario) VALUES
    ('2026-12-02 09:00', N'Primeira consulta de rotina', 1, 1, 1),
    ('2026-12-03 14:30', N'Paciente com sensibilidade no dente 36', 2, 2, 2),
    ('2026-12-05 10:15', N'Retorno para continuação do canal', 3, 3, 3),
    ('2026-12-09 16:00', N'Sessão de clareamento - 1ª etapa', 4, 4, 2),
    ('2026-12-12 08:30', N'Extração do siso inferior direito', 5, 5, 1),
    ('2026-11-30 11:00', N'Avaliação para aparelho ortodôntico', 1, 6, 3);
GO

/* ---------- Conferência ---------- */
SELECT * FROM dbo.usuario;
SELECT * FROM dbo.paciente;
SELECT * FROM dbo.procedimento;
SELECT * FROM dbo.agendamento ORDER BY data_consulta;
GO
