# ENTREGA 01 — Documentação de software

## 1.1 Requisitos Funcionais do Sistema

| ID | Requisito | Descrição |
|----|-----------|-----------|
| RF01 | Autenticação de usuários | O sistema deve permitir o login por usuário e senha. Em caso de falha (campos vazios, login inexistente ou senha incorreta), deve exibir mensagem de validação e não permitir o acesso. |
| RF02 | Expiração da sessão | A sessão do usuário deve expirar automaticamente após 20 minutos de inatividade, exigindo novo login. |
| RF03 | Tela principal | Após o login, o sistema deve exibir o nome do usuário logado, acesso aos recursos (Pacientes, Procedimentos e Agendamentos) e uma opção para sair do sistema. |
| RF04 | Encerrar sessão | O sistema deve permitir que o usuário saia (logout), encerrando a sessão e retornando à tela de login. |
| RF05 | Cadastrar paciente | O sistema deve permitir cadastrar pacientes (nome, CPF e telefone), validando o CPF e impedindo CPF duplicado. |
| RF06 | Buscar e listar pacientes | O sistema deve listar os pacientes e permitir informar um termo de busca (nome, telefone ou CPF); ao confirmar a pesquisa, a listagem é atualizada exibindo apenas os registros correspondentes. |
| RF07 | Editar paciente | O sistema deve permitir editar os dados de um paciente já cadastrado, salvando a alteração no banco de dados. |
| RF08 | Excluir paciente | O sistema deve permitir excluir um paciente, bloqueando a exclusão quando houver procedimentos ou agendamentos vinculados. |
| RF09 | Cadastrar procedimento | O sistema deve permitir cadastrar procedimentos odontológicos (nome e valor), associando-os obrigatoriamente a um paciente previamente cadastrado. |
| RF10 | Consultar, editar e excluir procedimento | O sistema deve listar os procedimentos com o paciente associado e permitir visualizar, editar e excluir (exclusão bloqueada se houver agendamentos vinculados). |
| RF11 | Agendar consulta | O sistema deve permitir agendar consulta informando paciente, procedimento (do paciente escolhido), data/hora e observações, registrando o usuário que realizou o agendamento. A data não pode estar no passado. |
| RF12 | Listar agendamentos | O sistema deve listar os agendamentos ordenados pela data da consulta, exibindo os dados do paciente (nome, CPF mascarado e telefone) e do procedimento (nome e valor). |
| RF13 | Atualizar data da consulta | O sistema deve permitir atualizar a data de uma consulta já cadastrada, salvando a alteração no banco de dados. |
| RF14 | Excluir agendamento | O sistema deve permitir excluir um agendamento cadastrado. |
| RF15 | Proteção de dados pessoais (LGPD) | O CPF deve ser armazenado criptografado e exibido mascarado nas listagens; as senhas devem ser armazenadas apenas como hash; todas as telas (exceto o login) exigem usuário autenticado. |

## 1.2 Regras de negócio atendidas

| Nº | Regra | Onde é atendida |
|----|-------|-----------------|
| 1 | Script com pelo menos 3 registros por tabela | `Database/script_banco_clinica.sql` (3 usuários, 5 pacientes, 6 procedimentos, 6 agendamentos) |
| 2 | Validação em caso de falha na autenticação | `AccountController.Login` + tela de login |
| 3 | Tela principal com usuário logado, acesso aos recursos e sair | `Views/Home/Index.cshtml` e barra de navegação (`_Layout`) |
| 4 | Busca de pacientes e edição de paciente | `PacienteController.Index` (busca) e `Edit` |
| 5 | Agendamentos ordenados por data, com dados do paciente/procedimento; atualizar data | `AgendamentoController.Index` e `Edit` |
| 6 | Procedimento obrigatoriamente associado a paciente cadastrado | `ProcedimentoController.Create` + FK `id_paciente NOT NULL` |

## Requisitos não funcionais

| ID | Requisito | Descrição |
|----|-----------|-----------|
| RNF01 | Tecnologia | ASP.NET Core MVC (.NET 8), Entity Framework Core e SQL Server. |
| RNF02 | Segurança | Autenticação por cookie (HttpOnly) com expiração; proteção CSRF (AntiForgeryToken) nos formulários. |
| RNF03 | Conformidade | Tratamento de dados pessoais em conformidade com a LGPD (Lei nº 13.709/2018). |
| RNF04 | Usabilidade | Interface em português (pt-BR), responsiva (Bootstrap), com mensagens de validação claras. |
