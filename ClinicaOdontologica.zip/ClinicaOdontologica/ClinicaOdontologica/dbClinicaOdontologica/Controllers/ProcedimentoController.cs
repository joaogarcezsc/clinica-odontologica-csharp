using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using dbClinicaOdontologica.Models;

namespace dbClinicaOdontologica.Controllers
{
    public class ProcedimentoController : Controller
    {
        private readonly DbClinicaOdontologicaContext _context;

        public ProcedimentoController(DbClinicaOdontologicaContext context)
        {
            _context = context;
        }

        // GET: Procedimento
        public async Task<IActionResult> Index()
        {
            var lista = await _context.Procedimentos
                .AsNoTracking()
                .Include(p => p.IdPacienteNavigation)
                .OrderBy(p => p.IdPacienteNavigation.Nome)
                .ThenBy(p => p.Nome)
                .ToListAsync();
            return View(lista);
        }

        // GET: Procedimento/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var procedimento = await _context.Procedimentos
                .AsNoTracking()
                .Include(p => p.IdPacienteNavigation)
                .FirstOrDefaultAsync(m => m.IdProcedimento == id);
            if (procedimento == null) return NotFound();

            return View(procedimento);
        }

        // GET: Procedimento/Create
        public async Task<IActionResult> Create()
        {
            await CarregarPacientesAsync(null);
            return View();
        }

        // POST: Procedimento/Create
        // Regra de negócio: todo procedimento deve ser associado a um paciente já cadastrado.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nome,Valor,IdPaciente")] Procedimento procedimento)
        {
            await ValidarAsync(procedimento);

            if (ModelState.IsValid)
            {
                _context.Add(procedimento);
                await _context.SaveChangesAsync();
                TempData["Sucesso"] = "Procedimento cadastrado com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            await CarregarPacientesAsync(procedimento.IdPaciente);
            return View(procedimento);
        }

        // GET: Procedimento/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var procedimento = await _context.Procedimentos.AsNoTracking().FirstOrDefaultAsync(p => p.IdProcedimento == id);
            if (procedimento == null) return NotFound();

            await CarregarPacientesAsync(procedimento.IdPaciente);
            return View(procedimento);
        }

        // POST: Procedimento/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdProcedimento,Nome,Valor,IdPaciente")] Procedimento procedimento)
        {
            if (id != procedimento.IdProcedimento) return NotFound();

            var existente = await _context.Procedimentos.FirstOrDefaultAsync(p => p.IdProcedimento == id);
            if (existente == null) return NotFound();

            await ValidarAsync(procedimento);

            if (ModelState.IsValid && existente.IdPaciente != procedimento.IdPaciente
                && await _context.Agendamentos.AnyAsync(a => a.IdProcedimento == id))
            {
                ModelState.AddModelError(nameof(Procedimento.IdPaciente),
                    "Não é possível trocar o paciente: este procedimento já possui agendamentos.");
            }

            if (ModelState.IsValid)
            {
                existente.Nome = procedimento.Nome;
                existente.Valor = procedimento.Valor;
                existente.IdPaciente = procedimento.IdPaciente;
                await _context.SaveChangesAsync();
                TempData["Sucesso"] = "Procedimento atualizado com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            await CarregarPacientesAsync(procedimento.IdPaciente);
            return View(procedimento);
        }

        // GET: Procedimento/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var procedimento = await _context.Procedimentos
                .AsNoTracking()
                .Include(p => p.IdPacienteNavigation)
                .FirstOrDefaultAsync(m => m.IdProcedimento == id);
            if (procedimento == null) return NotFound();

            return View(procedimento);
        }

        // POST: Procedimento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var procedimento = await _context.Procedimentos.FindAsync(id);
            if (procedimento == null) return RedirectToAction(nameof(Index));

            if (await _context.Agendamentos.AnyAsync(a => a.IdProcedimento == id))
            {
                TempData["Erro"] = "Não é possível excluir: o procedimento possui agendamentos vinculados.";
                return RedirectToAction(nameof(Index));
            }

            _context.Procedimentos.Remove(procedimento);
            await _context.SaveChangesAsync();
            TempData["Sucesso"] = "Procedimento excluído com sucesso.";
            return RedirectToAction(nameof(Index));
        }

        private async Task ValidarAsync(Procedimento procedimento)
        {
            if (procedimento.Valor <= 0)
            {
                ModelState.Remove(nameof(Procedimento.Valor));
                ModelState.AddModelError(nameof(Procedimento.Valor), "Informe um valor maior que zero.");
            }
            else if (procedimento.Valor > 99999999.99m)
            {
                ModelState.Remove(nameof(Procedimento.Valor));
                ModelState.AddModelError(nameof(Procedimento.Valor), "O valor informado é muito alto.");
            }

            if (!await _context.Pacientes.AnyAsync(p => p.IdPaciente == procedimento.IdPaciente))
            {
                ModelState.Remove(nameof(Procedimento.IdPaciente));
                ModelState.AddModelError(nameof(Procedimento.IdPaciente), "Selecione um paciente cadastrado.");
            }
        }

        private async Task CarregarPacientesAsync(int? selecionado)
        {
            var pacientes = await _context.Pacientes.AsNoTracking().OrderBy(p => p.Nome).ToListAsync();
            ViewBag.Pacientes = new SelectList(pacientes, "IdPaciente", "Nome", selecionado);
        }
    }
}
