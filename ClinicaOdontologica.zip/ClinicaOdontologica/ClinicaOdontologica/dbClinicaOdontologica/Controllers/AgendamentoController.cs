using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using dbClinicaOdontologica.Models;

namespace dbClinicaOdontologica.Controllers
{
    public class AgendamentoController : Controller
    {
        private readonly DbClinicaOdontologicaContext _context;

        public AgendamentoController(DbClinicaOdontologicaContext context)
        {
            _context = context;
        }

        // GET: Agendamento  (ordenado pela data da consulta)
        public async Task<IActionResult> Index()
        {
            var lista = await _context.Agendamentos
                .AsNoTracking()
                .Include(a => a.IdPacienteNavigation)
                .Include(a => a.IdProcedimentoNavigation)
                .Include(a => a.IdUsuarioNavigation)
                .OrderBy(a => a.DataConsulta)
                .ToListAsync();
            return View(lista);
        }

        // GET: Agendamento/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var agendamento = await CarregarAgendamentoAsync(id.Value, false);
            if (agendamento == null) return NotFound();

            return View(agendamento);
        }

        // GET: Agendamento/Create
        public async Task<IActionResult> Create()
        {
            await CarregarListasAsync();
            return View(new Agendamento { DataConsulta = DateTime.Today.AddDays(1).AddHours(9) });
        }

        // POST: Agendamento/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DataConsulta,Observacoes,IdPaciente,IdProcedimento")] Agendamento agendamento)
        {
            if (agendamento.DataConsulta == default)
            {
                ModelState.Remove(nameof(Agendamento.DataConsulta));
                ModelState.AddModelError(nameof(Agendamento.DataConsulta), "Informe a data e a hora da consulta.");
            }
            else if (agendamento.DataConsulta < DateTime.Now)
            {
                ModelState.Remove(nameof(Agendamento.DataConsulta));
                ModelState.AddModelError(nameof(Agendamento.DataConsulta), "A data da consulta não pode estar no passado.");
            }

            if (!await _context.Pacientes.AnyAsync(p => p.IdPaciente == agendamento.IdPaciente))
            {
                ModelState.Remove(nameof(Agendamento.IdPaciente));
                ModelState.AddModelError(nameof(Agendamento.IdPaciente), "Selecione um paciente cadastrado.");
            }

            var procedimento = await _context.Procedimentos.AsNoTracking()
                .FirstOrDefaultAsync(p => p.IdProcedimento == agendamento.IdProcedimento);
            if (procedimento == null)
            {
                ModelState.Remove(nameof(Agendamento.IdProcedimento));
                ModelState.AddModelError(nameof(Agendamento.IdProcedimento), "Selecione um procedimento cadastrado.");
            }
            else if (procedimento.IdPaciente != agendamento.IdPaciente)
            {
                ModelState.Remove(nameof(Agendamento.IdProcedimento));
                ModelState.AddModelError(nameof(Agendamento.IdProcedimento), "O procedimento selecionado pertence a outro paciente.");
            }

            if (ModelState.IsValid)
            {
                agendamento.IdUsuario = ObterIdUsuarioLogado();
                _context.Add(agendamento);
                await _context.SaveChangesAsync();
                TempData["Sucesso"] = "Consulta agendada com sucesso.";
                return RedirectToAction(nameof(Index));
            }

            await CarregarListasAsync();
            return View(agendamento);
        }

        // GET: Agendamento/Edit/5  (atualização da data da consulta)
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var agendamento = await CarregarAgendamentoAsync(id.Value, false);
            if (agendamento == null) return NotFound();

            return View(agendamento);
        }

        // POST: Agendamento/Edit/5
        // Somente a data (e as observações) podem ser alteradas; paciente e procedimento permanecem.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DateTime? dataConsulta, string? observacoes)
        {
            var agendamento = await CarregarAgendamentoAsync(id, true);
            if (agendamento == null) return NotFound();

            if (dataConsulta == null)
            {
                ModelState.AddModelError("dataConsulta", "Informe a data e a hora da consulta.");
            }
            else
            {
                bool dataMudou = dataConsulta.Value.ToString("yyyyMMddHHmm") != agendamento.DataConsulta.ToString("yyyyMMddHHmm");
                if (dataMudou && dataConsulta.Value < DateTime.Now)
                {
                    ModelState.AddModelError("dataConsulta", "A nova data da consulta não pode estar no passado.");
                }
            }

            if (observacoes != null && observacoes.Length > 255)
            {
                ModelState.AddModelError("observacoes", "As observações devem ter no máximo 255 caracteres.");
            }

            if (!ModelState.IsValid)
            {
                // Apenas para reexibir o que o usuário digitou (nada é salvo neste caminho)
                if (dataConsulta != null) agendamento.DataConsulta = dataConsulta.Value;
                agendamento.Observacoes = observacoes;
                return View(agendamento);
            }

            agendamento.DataConsulta = dataConsulta!.Value;
            agendamento.Observacoes = observacoes;
            await _context.SaveChangesAsync();

            TempData["Sucesso"] = "Data da consulta atualizada com sucesso.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Agendamento/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var agendamento = await CarregarAgendamentoAsync(id.Value, false);
            if (agendamento == null) return NotFound();

            return View(agendamento);
        }

        // POST: Agendamento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var agendamento = await _context.Agendamentos.FindAsync(id);
            if (agendamento != null)
            {
                _context.Agendamentos.Remove(agendamento);
                await _context.SaveChangesAsync();
                TempData["Sucesso"] = "Agendamento excluído com sucesso.";
            }
            return RedirectToAction(nameof(Index));
        }

        private async Task<Agendamento?> CarregarAgendamentoAsync(int id, bool rastrear)
        {
            IQueryable<Agendamento> query = _context.Agendamentos
                .Include(a => a.IdPacienteNavigation)
                .Include(a => a.IdProcedimentoNavigation)
                .Include(a => a.IdUsuarioNavigation);

            if (!rastrear) query = query.AsNoTracking();

            return await query.FirstOrDefaultAsync(a => a.IdAgendamento == id);
        }

        private async Task CarregarListasAsync()
        {
            ViewBag.Pacientes = await _context.Pacientes.AsNoTracking().OrderBy(p => p.Nome).ToListAsync();
            ViewBag.Procedimentos = await _context.Procedimentos.AsNoTracking().OrderBy(p => p.Nome).ToListAsync();
        }

        private int ObterIdUsuarioLogado()
        {
            string? valor = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return int.Parse(valor!);
        }
    }
}
