using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using dbClinicaOdontologica.Helpers;
using dbClinicaOdontologica.Models;

namespace dbClinicaOdontologica.Controllers
{
    public class PacienteController : Controller
    {
        private readonly DbClinicaOdontologicaContext _context;

        public PacienteController(DbClinicaOdontologicaContext context)
        {
            _context = context;
        }

        // GET: Paciente?busca=termo
        // Busca por nome, telefone ou CPF (CPF exato, com ou sem pontuação).
        public async Task<IActionResult> Index(string? busca)
        {
            var query = _context.Pacientes.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(busca))
            {
                string termo = busca.Trim();
                string? cpfFormatado = CpfHelper.TentarFormatar(termo);

                if (cpfFormatado != null)
                {
                    query = query.Where(p => p.Nome.Contains(termo) || p.Telefone.Contains(termo) || p.Cpf == cpfFormatado);
                }
                else
                {
                    query = query.Where(p => p.Nome.Contains(termo) || p.Telefone.Contains(termo));
                }
                ViewData["Busca"] = termo;
            }

            var pacientes = await query.OrderBy(p => p.Nome).ToListAsync();
            return View(pacientes);
        }

        // GET: Paciente/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var paciente = await _context.Pacientes
                .AsNoTracking()
                .Include(p => p.Procedimentos)
                .FirstOrDefaultAsync(m => m.IdPaciente == id);
            if (paciente == null) return NotFound();

            return View(paciente);
        }

        // GET: Paciente/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Paciente/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nome,Cpf,Telefone")] Paciente paciente)
        {
            await ValidarCpfAsync(paciente, null);

            if (ModelState.IsValid)
            {
                _context.Add(paciente);
                await _context.SaveChangesAsync();
                TempData["Sucesso"] = "Paciente cadastrado com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            return View(paciente);
        }

        // GET: Paciente/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var paciente = await _context.Pacientes.AsNoTracking().FirstOrDefaultAsync(p => p.IdPaciente == id);
            if (paciente == null) return NotFound();

            return View(paciente);
        }

        // POST: Paciente/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdPaciente,Nome,Cpf,Telefone")] Paciente paciente)
        {
            if (id != paciente.IdPaciente) return NotFound();

            var existente = await _context.Pacientes.FirstOrDefaultAsync(p => p.IdPaciente == id);
            if (existente == null) return NotFound();

            await ValidarCpfAsync(paciente, id);

            if (ModelState.IsValid)
            {
                existente.Nome = paciente.Nome;
                existente.Cpf = paciente.Cpf;
                existente.Telefone = paciente.Telefone;
                await _context.SaveChangesAsync();
                TempData["Sucesso"] = "Dados do paciente atualizados com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            return View(paciente);
        }

        // GET: Paciente/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var paciente = await _context.Pacientes.AsNoTracking().FirstOrDefaultAsync(m => m.IdPaciente == id);
            if (paciente == null) return NotFound();

            return View(paciente);
        }

        // POST: Paciente/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var paciente = await _context.Pacientes.FindAsync(id);
            if (paciente == null) return RedirectToAction(nameof(Index));

            bool possuiVinculos = await _context.Procedimentos.AnyAsync(p => p.IdPaciente == id)
                               || await _context.Agendamentos.AnyAsync(a => a.IdPaciente == id);
            if (possuiVinculos)
            {
                TempData["Erro"] = "Não é possível excluir: o paciente possui procedimentos ou agendamentos vinculados.";
                return RedirectToAction(nameof(Index));
            }

            _context.Pacientes.Remove(paciente);
            await _context.SaveChangesAsync();
            TempData["Sucesso"] = "Paciente excluído com sucesso.";
            return RedirectToAction(nameof(Index));
        }

        // Valida o CPF (dígitos verificadores), padroniza o formato e impede duplicidade.
        private async Task ValidarCpfAsync(Paciente paciente, int? idAtual)
        {
            if (string.IsNullOrWhiteSpace(paciente.Cpf)) return;

            if (!CpfHelper.Valido(paciente.Cpf))
            {
                ModelState.Remove(nameof(Paciente.Cpf));
                ModelState.AddModelError(nameof(Paciente.Cpf), "CPF inválido.");
                return;
            }

            string formatado = CpfHelper.TentarFormatar(paciente.Cpf)!;
            paciente.Cpf = formatado;

            bool duplicado = await _context.Pacientes.AnyAsync(p => p.Cpf == formatado && p.IdPaciente != (idAtual ?? 0));
            if (duplicado)
            {
                ModelState.Remove(nameof(Paciente.Cpf));
                ModelState.AddModelError(nameof(Paciente.Cpf), "Já existe um paciente cadastrado com este CPF.");
            }
        }
    }
}
