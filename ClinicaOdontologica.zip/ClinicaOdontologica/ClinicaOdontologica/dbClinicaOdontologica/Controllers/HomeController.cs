using System.Diagnostics;
using dbClinicaOdontologica.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dbClinicaOdontologica.Controllers
{
    public class HomeController : Controller
    {
        private readonly DbClinicaOdontologicaContext _context;

        public HomeController(DbClinicaOdontologicaContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.TotalPacientes = await _context.Pacientes.CountAsync();
            ViewBag.TotalProcedimentos = await _context.Procedimentos.CountAsync();
            ViewBag.TotalAgendamentos = await _context.Agendamentos.CountAsync();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [AllowAnonymous]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
