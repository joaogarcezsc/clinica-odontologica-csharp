using System.Globalization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using dbClinicaOdontologica.Helpers;
using dbClinicaOdontologica.Models;

var builder = WebApplication.CreateBuilder(args);

// Chave usada para criptografar o CPF (LGPD). Em produção: user-secrets ou variável de ambiente.
string chaveProtecao = builder.Configuration["Seguranca:ChaveProtecao"]
    ?? throw new InvalidOperationException("Configure 'Seguranca:ChaveProtecao' no appsettings.json.");
ProtecaoDados.Inicializar(chaveProtecao);

int minutosSessao = builder.Configuration.GetValue<int?>("Seguranca:MinutosExpiracaoSessao") ?? 20;

builder.Services.AddControllersWithViews(options =>
{
    // Mensagens de validação em português
    var msg = options.ModelBindingMessageProvider;
    msg.SetValueIsInvalidAccessor(v => $"O valor '{v}' é inválido.");
    msg.SetValueMustNotBeNullAccessor(v => "Informe um valor.");
    msg.SetMissingBindRequiredValueAccessor(v => $"Informe o campo {v}.");
    msg.SetAttemptedValueIsInvalidAccessor((v, campo) => $"O valor '{v}' não é válido para {campo}.");
    msg.SetValueMustBeANumberAccessor(campo => $"O campo {campo} deve ser numérico.");
    msg.SetNonPropertyValueMustBeANumberAccessor(() => "O valor deve ser numérico.");
});

builder.Services.AddDbContext<DbClinicaOdontologicaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConexaoSqlServer")));

// Autenticação por cookie com tempo de expiração (renovado a cada uso = expiração por inatividade)
builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/Login";
        options.Cookie.Name = "ClinicaOdontologica.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.ExpireTimeSpan = TimeSpan.FromMinutes(minutosSessao);
        options.SlidingExpiration = true;
    });

// Todo o sistema exige usuário autenticado, exceto onde houver [AllowAnonymous] (login e erro)
builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});

var app = builder.Build();

var cultura = new CultureInfo("pt-BR");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(cultura),
    SupportedCultures = new List<CultureInfo> { cultura },
    SupportedUICultures = new List<CultureInfo> { cultura }
});

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
