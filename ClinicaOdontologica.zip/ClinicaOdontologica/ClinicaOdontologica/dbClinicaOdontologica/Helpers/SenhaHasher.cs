using System.Security.Cryptography;

namespace dbClinicaOdontologica.Helpers
{
    /// <summary>Hash de senha: PBKDF2$iterações$salt(base64)$hash(base64)</summary>
    public static class SenhaHasher
    {
        private const int Iteracoes = 100000;
        private const int TamanhoSalt = 16;
        private const int TamanhoHash = 32;

        public static string Gerar(string senha)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(TamanhoSalt);
            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(senha, salt, Iteracoes, HashAlgorithmName.SHA256, TamanhoHash);
            return $"PBKDF2${Iteracoes}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
        }

        public static bool Verificar(string senha, string senhaArmazenada)
        {
            try
            {
                string[] partes = senhaArmazenada.Split('$');
                if (partes.Length != 4 || partes[0] != "PBKDF2") return false;

                int iteracoes = int.Parse(partes[1]);
                byte[] salt = Convert.FromBase64String(partes[2]);
                byte[] esperado = Convert.FromBase64String(partes[3]);
                byte[] calculado = Rfc2898DeriveBytes.Pbkdf2(senha, salt, iteracoes, HashAlgorithmName.SHA256, esperado.Length);
                return CryptographicOperations.FixedTimeEquals(calculado, esperado);
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
