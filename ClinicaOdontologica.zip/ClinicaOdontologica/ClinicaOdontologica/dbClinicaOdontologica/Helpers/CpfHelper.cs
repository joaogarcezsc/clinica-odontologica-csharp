namespace dbClinicaOdontologica.Helpers
{
    public static class CpfHelper
    {
        public static string SomenteDigitos(string? valor)
        {
            if (string.IsNullOrEmpty(valor)) return string.Empty;
            return new string(valor.Where(c => c >= '0' && c <= '9').ToArray());
        }

        public static string Formatar(string digitos)
        {
            return $"{digitos.Substring(0, 3)}.{digitos.Substring(3, 3)}.{digitos.Substring(6, 3)}-{digitos.Substring(9, 2)}";
        }

        /// <summary>Retorna o CPF no formato 000.000.000-00 se o texto tiver 11 dígitos; senão, null.</summary>
        public static string? TentarFormatar(string? valor)
        {
            string d = SomenteDigitos(valor);
            return d.Length == 11 ? Formatar(d) : null;
        }

        public static bool Valido(string? valor)
        {
            string d = SomenteDigitos(valor);
            if (d.Length != 11) return false;
            if (d.Distinct().Count() == 1) return false;

            int[] n = d.Select(c => c - '0').ToArray();

            int soma = 0;
            for (int i = 0; i < 9; i++) soma += n[i] * (10 - i);
            int dv1 = (soma * 10) % 11;
            if (dv1 == 10) dv1 = 0;
            if (dv1 != n[9]) return false;

            soma = 0;
            for (int i = 0; i < 10; i++) soma += n[i] * (11 - i);
            int dv2 = (soma * 10) % 11;
            if (dv2 == 10) dv2 = 0;
            return dv2 == n[10];
        }

        /// <summary>Máscara de exibição: ***.***.789-09 (minimização de dados – LGPD).</summary>
        public static string Mascarar(string? cpf)
        {
            string d = SomenteDigitos(cpf);
            if (d.Length != 11) return "***.***.***-**";
            return $"***.***.{d.Substring(6, 3)}-{d.Substring(9, 2)}";
        }
    }
}
