using System.Security.Cryptography;
using System.Text;

namespace dbClinicaOdontologica.Helpers
{
    /// <summary>
    /// Proteção de dados pessoais (LGPD): criptografia do CPF em repouso (AES-256-CBC)
    /// e hash de senhas (PBKDF2-SHA256 com salt aleatório).
    /// A criptografia do CPF é determinística (IV derivado de HMAC do próprio valor),
    /// o que permite manter a restrição UNIQUE e pesquisar por CPF exato sem expor o dado no banco.
    /// </summary>
    public static class ProtecaoDados
    {
        private static byte[]? _chaveCripto;
        private static byte[]? _chaveMac;

        public static void Inicializar(string segredo)
        {
            _chaveCripto = SHA256.HashData(Encoding.UTF8.GetBytes(segredo + "|enc"));
            _chaveMac = SHA256.HashData(Encoding.UTF8.GetBytes(segredo + "|mac"));
        }

        public static string Criptografar(string texto)
        {
            if (_chaveCripto == null || _chaveMac == null)
                throw new InvalidOperationException("ProtecaoDados não foi inicializada.");

            byte[] plano = Encoding.UTF8.GetBytes(texto);
            byte[] iv = HMACSHA256.HashData(_chaveMac, plano)[..16];

            using var aes = Aes.Create();
            aes.Key = _chaveCripto;
            byte[] cifrado = aes.EncryptCbc(plano, iv, PaddingMode.PKCS7);

            byte[] saida = new byte[16 + cifrado.Length];
            iv.CopyTo(saida, 0);
            cifrado.CopyTo(saida, 16);
            return Convert.ToBase64String(saida);
        }

        public static string Descriptografar(string valor)
        {
            if (_chaveCripto == null)
                throw new InvalidOperationException("ProtecaoDados não foi inicializada.");

            try
            {
                byte[] dados = Convert.FromBase64String(valor);
                if (dados.Length < 32) return valor;

                byte[] iv = dados[..16];
                byte[] cifrado = dados[16..];

                using var aes = Aes.Create();
                aes.Key = _chaveCripto;
                byte[] plano = aes.DecryptCbc(cifrado, iv, PaddingMode.PKCS7);
                return Encoding.UTF8.GetString(plano);
            }
            catch (Exception ex) when (ex is FormatException || ex is CryptographicException)
            {
                // Registro antigo gravado em texto puro: devolve como está.
                return valor;
            }
        }
    }
}
