using System;
using System.Collections.Generic;

namespace dbClinicaOdontologica.Models;

public partial class Usuario
{
    public int IdUsuario { get; set; }

    public string Nome { get; set; } = null!;

    public string Login { get; set; } = null!;

    /// <summary>Hash PBKDF2 da senha (nunca a senha em texto puro).</summary>
    public string Senha { get; set; } = null!;

    public virtual ICollection<Agendamento> Agendamentos { get; set; } = new List<Agendamento>();
}
