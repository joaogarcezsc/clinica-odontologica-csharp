using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace dbClinicaOdontologica.Models;

public partial class Agendamento
{
    public int IdAgendamento { get; set; }

    [Required(ErrorMessage = "Informe a data e a hora da consulta.")]
    [Display(Name = "Data da consulta")]
    public DateTime DataConsulta { get; set; }

    [StringLength(255, ErrorMessage = "As observações devem ter no máximo 255 caracteres.")]
    [Display(Name = "Observações")]
    public string? Observacoes { get; set; }

    [Required(ErrorMessage = "Selecione um paciente cadastrado.")]
    [Range(1, int.MaxValue, ErrorMessage = "Selecione um paciente cadastrado.")]
    [Display(Name = "Paciente")]
    public int IdPaciente { get; set; }

    [Required(ErrorMessage = "Selecione um procedimento.")]
    [Range(1, int.MaxValue, ErrorMessage = "Selecione um procedimento.")]
    [Display(Name = "Procedimento")]
    public int IdProcedimento { get; set; }

    public int IdUsuario { get; set; }

    public virtual Paciente IdPacienteNavigation { get; set; } = null!;

    public virtual Procedimento IdProcedimentoNavigation { get; set; } = null!;

    public virtual Usuario IdUsuarioNavigation { get; set; } = null!;
}
