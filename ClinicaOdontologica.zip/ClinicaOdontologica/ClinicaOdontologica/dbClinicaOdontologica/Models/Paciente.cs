using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace dbClinicaOdontologica.Models;

public partial class Paciente
{
    public int IdPaciente { get; set; }

    [Required(ErrorMessage = "Informe o nome do paciente.")]
    [StringLength(100, ErrorMessage = "O nome deve ter no máximo 100 caracteres.")]
    [Display(Name = "Nome")]
    public string Nome { get; set; } = null!;

    [Required(ErrorMessage = "Informe o CPF.")]
    [Display(Name = "CPF")]
    public string Cpf { get; set; } = null!;

    [Required(ErrorMessage = "Informe o telefone.")]
    [StringLength(20, ErrorMessage = "O telefone deve ter no máximo 20 caracteres.")]
    [Display(Name = "Telefone")]
    public string Telefone { get; set; } = null!;

    public virtual ICollection<Agendamento> Agendamentos { get; set; } = new List<Agendamento>();

    public virtual ICollection<Procedimento> Procedimentos { get; set; } = new List<Procedimento>();
}
