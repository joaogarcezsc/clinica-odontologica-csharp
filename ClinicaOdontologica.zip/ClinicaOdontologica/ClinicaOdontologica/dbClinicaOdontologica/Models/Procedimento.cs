using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace dbClinicaOdontologica.Models;

public partial class Procedimento
{
    public int IdProcedimento { get; set; }

    [Required(ErrorMessage = "Informe o nome do procedimento.")]
    [StringLength(100, ErrorMessage = "O nome deve ter no máximo 100 caracteres.")]
    [Display(Name = "Procedimento")]
    public string Nome { get; set; } = null!;

    [Required(ErrorMessage = "Informe o valor do procedimento.")]
    [Display(Name = "Valor (R$)")]
    public decimal Valor { get; set; }

    [Required(ErrorMessage = "Selecione um paciente cadastrado.")]
    [Range(1, int.MaxValue, ErrorMessage = "Selecione um paciente cadastrado.")]
    [Display(Name = "Paciente")]
    public int IdPaciente { get; set; }

    public virtual ICollection<Agendamento> Agendamentos { get; set; } = new List<Agendamento>();

    public virtual Paciente IdPacienteNavigation { get; set; } = null!;
}
