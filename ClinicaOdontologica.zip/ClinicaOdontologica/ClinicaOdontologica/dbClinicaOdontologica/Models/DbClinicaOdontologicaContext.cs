using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using dbClinicaOdontologica.Helpers;

namespace dbClinicaOdontologica.Models;

public partial class DbClinicaOdontologicaContext : DbContext
{
    public DbClinicaOdontologicaContext()
    {
    }

    public DbClinicaOdontologicaContext(DbContextOptions<DbClinicaOdontologicaContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Agendamento> Agendamentos { get; set; }

    public virtual DbSet<Paciente> Pacientes { get; set; }

    public virtual DbSet<Procedimento> Procedimentos { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer("Name=ConexaoSqlServer");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // CPF é gravado criptografado no banco (LGPD) e descriptografado ao ler.
        var cpfConverter = new ValueConverter<string, string>(
            v => ProtecaoDados.Criptografar(v),
            v => ProtecaoDados.Descriptografar(v));

        modelBuilder.Entity<Agendamento>(entity =>
        {
            entity.HasKey(e => e.IdAgendamento).HasName("pk_agendamento");

            entity.ToTable("agendamento");

            entity.Property(e => e.IdAgendamento).HasColumnName("id_agendamento");
            entity.Property(e => e.DataConsulta)
                .HasColumnType("datetime")
                .HasColumnName("data_consulta");
            entity.Property(e => e.IdPaciente).HasColumnName("id_paciente");
            entity.Property(e => e.IdProcedimento).HasColumnName("id_procedimento");
            entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");
            entity.Property(e => e.Observacoes)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("observacoes");

            entity.HasOne(d => d.IdPacienteNavigation).WithMany(p => p.Agendamentos)
                .HasForeignKey(d => d.IdPaciente)
                .OnDelete(DeleteBehavior.Restrict)
                .HasConstraintName("fk_agendamento_paciente");

            entity.HasOne(d => d.IdProcedimentoNavigation).WithMany(p => p.Agendamentos)
                .HasForeignKey(d => d.IdProcedimento)
                .OnDelete(DeleteBehavior.Restrict)
                .HasConstraintName("fk_agendamento_procedimento");

            entity.HasOne(d => d.IdUsuarioNavigation).WithMany(p => p.Agendamentos)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.Restrict)
                .HasConstraintName("fk_agendamento_usuario");
        });

        modelBuilder.Entity<Paciente>(entity =>
        {
            entity.HasKey(e => e.IdPaciente).HasName("pk_paciente");

            entity.ToTable("paciente");

            entity.HasIndex(e => e.Cpf, "uq_paciente_cpf").IsUnique();

            entity.Property(e => e.IdPaciente).HasColumnName("id_paciente");
            entity.Property(e => e.Cpf)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasConversion(cpfConverter)
                .HasColumnName("cpf");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nome");
            entity.Property(e => e.Telefone)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("telefone");
        });

        modelBuilder.Entity<Procedimento>(entity =>
        {
            entity.HasKey(e => e.IdProcedimento).HasName("pk_procedimento");

            entity.ToTable("procedimento");

            entity.Property(e => e.IdProcedimento).HasColumnName("id_procedimento");
            entity.Property(e => e.IdPaciente).HasColumnName("id_paciente");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nome");
            entity.Property(e => e.Valor)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("valor");

            entity.HasOne(d => d.IdPacienteNavigation).WithMany(p => p.Procedimentos)
                .HasForeignKey(d => d.IdPaciente)
                .OnDelete(DeleteBehavior.Restrict)
                .HasConstraintName("fk_procedimento_paciente");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.IdUsuario).HasName("pk_usuario");

            entity.ToTable("usuario");

            entity.HasIndex(e => e.Login, "uq_usuario_login").IsUnique();

            entity.Property(e => e.IdUsuario).HasColumnName("id_usuario");
            entity.Property(e => e.Login)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("login");
            entity.Property(e => e.Nome)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("nome");
            entity.Property(e => e.Senha)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("senha");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
