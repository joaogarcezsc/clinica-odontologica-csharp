# 🦷 Sistema de Gestão de Clínica Odontológica

Sistema web em **ASP.NET Core MVC (.NET 8)** com **Entity Framework Core** e **SQL Server** para cadastro e gerenciamento de pacientes, procedimentos odontológicos e agendamento de consultas, com autenticação com tempo de expiração e proteção de dados pessoais (LGPD).

## Entregas

| Entrega | Conteúdo | Arquivo |
|---------|----------|---------|
| 01 | Requisitos funcionais | [`docs/Requisitos_Funcionais.md`](docs/Requisitos_Funcionais.md) |
| 02 | Diagrama Entidade-Relacionamento (DER) | [`docs/DER_Clinica_Odontologica.png`](docs/DER_Clinica_Odontologica.png) |
| 03 | Script de criação e população do banco | [`Database/script_banco_clinica.sql`](Database/script_banco_clinica.sql) |
| 04 | Projeto no Git | este repositório |

## DER

![DER](docs/DER_Clinica_Odontologica.png)

```mermaid
erDiagram
    USUARIO  ||--o{ AGENDAMENTO  : registra
    PACIENTE ||--o{ PROCEDIMENTO : possui
    PACIENTE ||--o{ AGENDAMENTO  : realiza
    PROCEDIMENTO ||--o{ AGENDAMENTO : "é agendado em"
```

## Como executar

1. Abra o **SQL Server Management Studio** e execute o script `Database/script_banco_clinica.sql` (cria o banco `dbClinicaOdontologica`, as tabelas e os registros).
2. Confira a *connection string* em `dbClinicaOdontologica/appsettings.json` (`ConexaoSqlServer`) e ajuste o servidor/usuário/senha conforme o seu SQL Server.
3. Abra `dbClinicaOdontologica.sln` no Visual Studio 2022 e execute (F5), ou na pasta do projeto: `dotnet run`.

### Usuários para teste

| Login | Senha |
|-------|-------|
| `admin` | `Admin@123` |
| `recepcao` | `Recep@123` |
| `dentista` | `Dente@123` |

## Segurança e LGPD

- **Autenticação por cookie** com expiração por inatividade (20 minutos – `Seguranca:MinutosExpiracaoSessao`). Todas as telas exigem login, exceto a de acesso.
- **Senhas** armazenadas apenas como hash PBKDF2-SHA256 com salt individual.
- **CPF criptografado** no banco (AES-256) e **mascarado** nas listagens (`***.***.789-09`).
- Formulários protegidos contra CSRF (`ValidateAntiForgeryToken`).

> ⚠️ O CPF dos registros do script foi criptografado com a chave de desenvolvimento em `appsettings.json` (`Seguranca:ChaveProtecao`). Se trocar a chave, gere novamente os CPFs (ou cadastre os pacientes pelo sistema).

## Funcionalidades

- **Login / Sair**, com mensagem de validação em caso de falha.
- **Tela principal** com o nome do usuário logado, acesso aos recursos e botão *Sair*.
- **Pacientes:** cadastro, **busca por termo** (nome, telefone ou CPF), **edição**, detalhes e exclusão.
- **Procedimentos:** cadastro (**obrigatoriamente associado a um paciente cadastrado**), edição, detalhes e exclusão.
- **Agendamentos:** listagem **ordenada pela data da consulta** com os dados do paciente e do procedimento, cadastro, **atualização da data** da consulta e exclusão.

## Estrutura

```
Database/        script SQL Server (criação + população)
docs/            requisitos funcionais e DER
dbClinicaOdontologica/
  Controllers/   Account, Home, Paciente, Procedimento, Agendamento
  Models/        entidades, DbContext e LoginViewModel
  Helpers/       ProtecaoDados (AES), SenhaHasher (PBKDF2), CpfHelper
  Views/         telas Razor
```
